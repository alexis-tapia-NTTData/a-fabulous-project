package com.nttdata.ncnp.api.config;

import com.nttdata.ncnp.adapter.spring.autoconfigure.NCNPTracing;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
    NCNPTracing.class
    })

public class ApplicationConfiguration {

}
