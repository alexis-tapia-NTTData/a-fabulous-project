# Slug123

## Sobre arquitectura web


## Iniciando

Siga las siguientes instrucciones para iniciar el desarrollo de este proyecto.

### Pre-Requisitos

Plugins que deben estar instalados en su IDE:
* [Lombok](http://projectlombok.org/) - *Libreria de Bytecode que genera automaticamente los Getters y Setters*.
* [CheckStyle](http://www.checkstyle.com/) - *Plugin para poder comprobar el estilo del codigo usando las reglas de Google*
* FindBugs - *Plugin que realiza un análisis estático para buscar errores en el código en base a patrones de errores.* 

---

## Flujo de desarrollo.

* Todo desarrollo debe iniciarse en una rama con la nomenclatura `feature/nombre-de-cambio` el cual debe crearse desde la rama `develop`.

* Cuando se completa el desarrollo, se deberá generar un `New Merge Request` desde la rama creada `feature/nombre-de-cambio` hacia la rama `develop`.

* Cuando los cambios son revisados y probados, se aceptará el Merge Request, con lo que los cambios quedarán listos en la rama `develop` para realizar el despliegue en el ambiente de desarrollo.



## Ejecución de pruebas

Para la ejecución de pruebas `unitarias` se debe ejecutar lo siguiente:

```
mvn test
```

Para la ejecución de pruebas de `integración` se debe ejecutar lo siguiente:

```
mvn verify -Dskip.integration.tests=false -Dskip.unit.tests=true
```
