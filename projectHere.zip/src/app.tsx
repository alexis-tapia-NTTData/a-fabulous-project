import React from "react";
import { BrowserRouter as Router, Route, Switch, Redirect } from "react-router-dom";
import home from "./app/view/home";


import "./app.scss";

const App = () => {
  return (
      <Router>
      <Switch>
            <Route exact path="/home" component={home} key="home" />
          <Redirect exact from="/" to="/" />
          </Switch>
      </Router>
  );
};

export default App;