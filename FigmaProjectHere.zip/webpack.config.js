const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const InterpolateHtmlPlugin = require("interpolate-html-plugin");
const webpack = require("webpack");
const Config = require("./ncnp.json");
const getPublicUrlOrPath = require("react-dev-utils/getPublicUrlOrPath");
const path = require("path");
const fs = require("fs");
// Do this as the first thing so that any code reading it knows the right env.
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const imageInlineSizeLimit = parseInt(
  process.env.IMAGE_INLINE_SIZE_LIMIT || "10000",
);
const REACT_APP = /^REACT_APP_/i;

function getClientEnvironment(publicUrl) {
  const raw = Object.keys(process.env)
    .filter((key) => REACT_APP.test(key))
    .reduce(
      (env, key) => {
        env[key] = process.env[key];
        return env;
      },
      {
        // Useful for determining whether we’re running in production mode.
        // Most importantly, it switches React into the correct mode.
        NODE_ENV: process.env.NODE_ENV || "development",
        // Useful for resolving the correct path to static assets in `public`.
        // For example, <img src={process.env.PUBLIC_URL + '/img/logo.png'} />.
        // This should only be used as an escape hatch. Normally you would put
        // images into the `src` and `import` them in code to get their paths.
        PUBLIC_URL: publicUrl,
        // We support configuring the sockjs pathname during development.
        // These settings let a developer run multiple simultaneous projects.
        // They are used as the connection `hostname`, `pathname` and `port`
        // in webpackHotDevClient. They are used as the `sockHost`, `sockPath`
        // and `sockPort` options in webpack-dev-server.
        WDS_SOCKET_HOST: process.env.WDS_SOCKET_HOST,
        WDS_SOCKET_PATH: process.env.WDS_SOCKET_PATH,
        WDS_SOCKET_PORT: process.env.WDS_SOCKET_PORT,
        // Whether or not react-refresh is enabled.
        // It is defined here so it is available in the webpackHotDevClient.
        FAST_REFRESH: process.env.FAST_REFRESH !== "false",
      },
    );
  // Stringify all values so we can feed into webpack DefinePlugin
  const stringified = {
    "process.env": Object.keys(raw).reduce((env, key) => {
      env[key] = JSON.stringify(raw[key]);
      return env;
    }, {}),
  };

  return { raw, stringified };
}
const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = (relativePath) => path.resolve(appDirectory, relativePath);
module.exports = (options) => {
  process.env.PUBLIC_URL = process.env.REACT_APP_HOST;
  process.env.NODE_ENV = options.NODE_ENV;
  process.env.BABEL_ENV = process.env.NODE_ENV;
  const publicUrlOrPath = getPublicUrlOrPath(
    process.env.NODE_ENV === "development",
    require(resolveApp("package.json")).homepage,
    process.env.PUBLIC_URL,
  );
  const enviroment = getClientEnvironment(publicUrlOrPath.slice(0, -1));
  console.log(enviroment.raw);
  return {
    mode: options.NODE_ENV,
    entry: "./src/index.tsx",
    output: {
      path: path.join(__dirname, "build"),
      filename: "bundle.js",
      publicPath: "auto",
      uniqueName: Config.name,
    },
    module: {
      rules: [
        {
          test: /\.(css|scss)$/,
          use: [
            MiniCssExtractPlugin.loader,
            "css-loader",
            "postcss-loader",
            "sass-loader",
          ],
        },
        {
          // "oneOf" will traverse all following loaders until one will
          // match the requirements. When no loader matches it will fall
          // back to the "file" loader at the end of the loader list.
          oneOf: [
            {
              test: /\.(ts|tsx)$/,
              use: [
                {
                  loader: "babel-loader",
                  options: {
                    cacheDirectory: true,
                    presets: [require.resolve("babel-preset-react-app")],
                  },
                },
              ],
            },
            {
              test: /\.(js)$/,
              use: {
                loader: "babel-loader",
              },
              resolve: {
                fullySpecified: false,
              },
            },
            {
              test: /\.(ts|tsx)$/,
              loader: "ts-loader",
            },
            // TODO: Merge this config once `image/avif` is in the mime-db
            // https://github.com/jshttp/mime-db
            {
              test: [/\.avif$/],
              type: "asset",
              mimetype: "image/avif",
              parser: {
                dataUrlCondition: {
                  maxSize: imageInlineSizeLimit,
                },
              },
            },
            // "url" loader works like "file" loader except that it embeds assets
            // smaller than specified limit in bytes as data URLs to avoid requests.
            // A missing `test` is equivalent to a match.
            {
              test: [/\.bmp$/, /\.gif$/, /\.jpe?g$/, /\.png$/],
              type: "asset",
              parser: {
                dataUrlCondition: {
                  maxSize: imageInlineSizeLimit,
                },
              },
            },
            {
              test: /\.svg$/,
              use: [
                {
                  loader: require.resolve("@svgr/webpack"),
                  options: {
                    prettier: false,
                    svgo: false,
                    svgoConfig: {
                      plugins: [{ removeViewBox: false }],
                    },
                    titleProp: true,
                    ref: true,
                  },
                },
                {
                  loader: require.resolve("file-loader"),
                  options: {
                    name: "static/media/[name].[hash].[ext]",
                  },
                },
              ],
              issuer: {
                and: [/\.(ts|tsx|js|jsx|md|mdx)$/],
              },
            },

            // "file" loader makes sure those assets get served by WebpackDevServer.
            // When you `import` an asset, you get its (virtual) filename.
            // In production, they would get copied to the `build` folder.
            // This loader doesn't use a "test" so it will catch all modules
            // that fall through the other loaders.
            {
              // Exclude `js` files to keep "css" loader working as it injects
              // its runtime that would otherwise be processed through "file" loader.
              // Also exclude `html` and `json` extensions so they get processed
              // by webpacks internal loaders.
              exclude: [/^$/, /\.(js|mjs|jsx|ts|tsx)$/, /\.html$/, /\.json$/],
              type: "asset/resource",
            },
            // * STOP * Are you adding a new loader?
            // Make sure to add the new loader(s) before the "file" loader.
          ],
        },
      ],
    },
    resolve: {
      extensions: [".ts", ".tsx", ".js", ".css", ".scss", ".svg", ".json"],
    },
    plugins: [
      new ModuleFederationPlugin({
        name: "react",
        library: {
          type: "var",
          name: Config.name,
        },
        filename: "remoteEntry.js",
        exposes: {
          "./web-components": "./src/index.tsx",
        },
        shared: [] /*  ["react", "react-dom", "ncnp"], */,
      }),
      new HtmlWebpackPlugin({
        publicPath: process.env.PUBLIC_URL,
        template: "./src/public/index.html",
        inject: false,
      }),
      new InterpolateHtmlPlugin(enviroment.raw),
      new MiniCssExtractPlugin({
        filename: Config.name + ".css",
        chunkFilename: Config.name + ".css",
      }),

      new webpack.DefinePlugin(enviroment.stringified),
      new webpack.ProvidePlugin({
        React: "react",
      }),
    ],
    devServer: {
      port: Config.port,
      historyApiFallback: true,
    },
  };
};
