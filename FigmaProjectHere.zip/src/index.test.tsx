import "./index";

test("should create web component", () => {
  const entryWebComponent = customElements.get("react-element");
  const instance = new entryWebComponent();
  instance.connectedCallback();
  expect(instance).toBeDefined();
});
