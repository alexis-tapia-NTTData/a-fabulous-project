import { createRoot } from "react-dom/client";

import ncnp from "../ncnp.json";
import App from "./app";

declare global {
  interface Window {
    mfe_login: ReactMfe;
  }
}
const nodesGlobal: HTMLElement[] = [];
function parseInlineStyleTags(head: any, newContainer: any, selector: any) {
  const allStyles = document.querySelectorAll("style");
  const arrayStyles = [...allStyles];
  if (arrayStyles && arrayStyles.length) {
    arrayStyles.forEach((style) => {
      const id = Math.random().toString(36).substring(2, 10);
      style.setAttribute("id", id.toString());
      nodesGlobal.push(style);
      selector.querySelector(".app-styles-container").append(style);
    });
    postProccessStyle(newContainer);
  }
  const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
      if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
        const addedNodes = Array.from(mutation.addedNodes);
        const addedStyles = addedNodes.filter(
          (node) => node.nodeName === "STYLE",
        );

        addedStyles.forEach((_x, pos) => {
          const id = Math.random().toString(36).substring(2, 10);
          const node = addedStyles[pos] as HTMLElement;
          head.removeChild(node);
          node.setAttribute("id", id);
          nodesGlobal.push(node);
          newContainer.innerHTML += node.outerHTML;
        });
        postProccessStyle(newContainer);
      }
    }
  });

  const observerOptions = {
    childList: true,
  };

  observer.observe(head, observerOptions);
  return observer;
}
export default class ReactMfe extends HTMLElement {
  observer: MutationObserver = null as unknown as MutationObserver;

  connectedCallback() {
    this.innerHTML =
      '<div class="app-element-container"></div><div class="app-styles-container"> <link rel="stylesheet" href="' +
      process.env.REACT_APP_HOST +
      "/" +
      ncnp.name +
      '.css"/></div>';
    const container = this.querySelector(".app-element-container") as Element;
    const styleContainer = this.querySelector(".app-styles-container");
    const headElement = document.querySelector("head");
    const root = createRoot(container);
    root.render(<App />);
    this.observer = parseInlineStyleTags(headElement, styleContainer, this);

    window.mfe_login = this;
  }

  disconnectedCallback() {
    this.observer.disconnect();
  }
}
function postProccessStyle(newContainer) {
  for (let index = 0; index < nodesGlobal.length; index++) {
    const element = nodesGlobal[index];

    const result = newContainer.querySelector(
      'style[id="' + element.getAttribute("id") + '"]',
    );
    if (!result) {
      newContainer.innerHTML += element.outerHTML;
    }
  }
}
customElements.define("react-element", ReactMfe);
