
  
  
  import img_1509 from '../../../assets/images/1509.webp';
import img_152 from '../../../assets/images/152.webp';
import img_158 from '../../../assets/images/158.webp';
import img_166 from '../../../assets/images/166.webp';
import img_1131 from '../../../assets/images/1131.webp';
import img_1137 from '../../../assets/images/1137.webp';
import img_1145 from '../../../assets/images/1145.webp';
import img_1154 from '../../../assets/images/1154.webp';
import img_1159 from '../../../assets/images/1159.webp';
import img_1164 from '../../../assets/images/1164.webp';
import img_1170 from '../../../assets/images/1170.webp';
import img_1174 from '../../../assets/images/1174.webp';
import img_1175 from '../../../assets/images/1175.webp';
import img_1176 from '../../../assets/images/1176.webp';
import img_1177 from '../../../assets/images/1177.webp';
import img_1183 from '../../../assets/images/1183.webp';
import img_1187 from '../../../assets/images/1187.webp';
import img_1191 from '../../../assets/images/1191.webp';
import img_1195 from '../../../assets/images/1195.webp';
import img_1199 from '../../../assets/images/1199.webp';
import img_1203 from '../../../assets/images/1203.webp';
import img_1207 from '../../../assets/images/1207.webp';
import img_1211 from '../../../assets/images/1211.webp';
import img_1215 from '../../../assets/images/1215.webp';
import img_1219 from '../../../assets/images/1219.webp';
import img_1225 from '../../../assets/images/1225.webp';

  
  import './home.scss';

const Home = () => {
return (
<div className="home">
        <div className="header">
        <div className="communication-banner">
        <span className="text-banner-description">Cirtical communication block text and access to landing page - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue luctus neque eget hendrerit. Nam sit amet blandit lectus, id laoreet enim. Ut rutrum turpis leo, vel luctus felis tempor sed. Vestibulum eget posuere lacus, a finibus ex. Read more critical communications here.</span>
        </div><div className="sub-menu">
        <span className="subment-text">Pichincha</span><span className="subment-text">|</span><span className="subment-text">Critical Communications</span>
        </div><div className="main-header-frame">
        <div className="elements">
        <img className="pichincha-logo" src={img_1509} alt="pichincha-logo" /><div className="loged-in-name">
        <img className="user-icon" src={img_152} alt="user-icon" /><span className="user-text">Emma Smith</span>
        </div>
        </div>
        </div>
        </div><div className="section-stories">
        <div className="top-story">
        <div className="image-slider">
        <div className="frame-1">
        <img className="image-1" src={img_158} alt="image-1" />
        </div>
        </div><div className="top-story-information-wrapper">
        <div className="top-story-information-title">
        <span className="top-story-text-date">December 22, 2023</span><span className="top-story-text-title">Ventajas de tu cuenta sueldo</span>
        </div><span className="top-story-text-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio. Aliquam malesuada tellus rhoncus urna tempus, sed porta lacus hendrerit. Aliquam erat volutpat. Nam congue erat non maximus efficitur. Praesent ut luctus quam. Fusce mattis at dolor vitae sagittis. Phasellus sit amet lacus mattis, pellentesque diam a, hendrerit erat. Nullam interdum ligula sit amet eleifend egestas.</span><div className="top-story-link">
        <span className="top-story-text-button">Read more</span><img className="arrow-go" src={img_166} alt="arrow-go" />
        </div>
        </div>
        </div><div className="stories-grid">
        <div className="news-story">
        <div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div><div className="mosaic-story">
        <div className="mosaic-container">
        <span className="mosaic-date">12/20/23</span><div className="mosaic-img-contain">
        
        </div>
        </div><span className="mosaic-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div>
        </div><div className="sories-see-all">
        <span className="sories-see-all-button">See all</span><img className="arrow-go" src={img_1131} alt="arrow-go" />
        </div>
        </div>
        </div><div className="section-photos">
        <div className="column-card">
        <div className="cc-view">
        <span className="cc-view-title">Eventos Perú</span><div className="cc-view-img">
        <img className="winter-wonder" src={img_1137} alt="winter-wonder" />
        </div>
        </div><div className="cc-information">
        <span className="cc-inf-title">A Winter Wonderland</span><span className="cc-inf-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci.<br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div>
        </div><div className="column-card">
        <div className="cc-view">
        <span className="cc-view-title">Eventos Ecuador</span><div className="cc-view-img">
        <img className="image-6" src={img_1145} alt="image-6" />
        </div>
        </div><div className="cc-information">
        <span className="cc-inf-title">A Winter Wonderland</span><span className="cc-inf-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci.<br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus orci justo, sodales at ultrices nec, bibendum quis odio.</span>
        </div>
        </div>
        </div><div className="section-points">
        <span className="pp-title">Puntos clave</span><div className="pp-contain">
        <div className="pp-co-small-card">
        <div className="pp-co-sc-co-img">
        <img className="sc-img" src={img_1154} alt="sc-img" />
        </div><span className="pp-co-sc-title">Techbar Update</span><span className="pp-co-sc-text">Do you need some assistance with your computer? To schedule time for regular Techbar sessions as well as sessions at the MOBILE Techbars, click on this link: Report an issue - Iberdrola (service-now.com).</span>
        </div><div className="pp-co-small-card">
        <div className="pp-co-sc-co-img">
        <img className="sc-img" src={img_1159} alt="sc-img" />
        </div><span className="pp-co-sc-title">Techbar Update</span><span className="pp-co-sc-text">Do you need some assistance with your computer? To schedule time for regular Techbar sessions as well as sessions at the MOBILE Techbars, click on this link: Report an issue - Iberdrola (service-now.com).</span>
        </div><div className="pp-co-small-card">
        <div className="pp-co-sc-co-img">
        <img className="sc-img" src={img_1164} alt="sc-img" />
        </div><span className="pp-co-sc-title">Techbar Update</span><span className="pp-co-sc-text">Do you need some assistance with your computer? To schedule time for regular Techbar sessions as well as sessions at the MOBILE Techbars, click on this link: Report an issue - Iberdrola (service-now.com).</span>
        </div>
        </div>
        </div><div className="section-info">
        <div className="pic-col">
        <span className="pic-col-title">Acerca de nosotros</span><img className="form-background" src={img_1170} alt="form-background" />
        </div><div className="pic-col">
        <span className="pic-col-title">Información</span><div className="pic-col-contain">
        <img className="pic-img" src={img_1174} alt="pic-img" /><img className="pic-img" src={img_1175} alt="pic-img" /><img className="pic-img" src={img_1176} alt="pic-img" /><img className="pic-img" src={img_1177} alt="pic-img" />
        </div>
        </div>
        </div><div className="section-links">
        <span className="ul-title">Enlaces útiles</span><div className="ul-contain">
        <div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1183} alt="cu-icon" /><span className="cu-title">Info</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1187} alt="cu-icon" /><span className="cu-title">Benefits</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1191} alt="cu-icon" /><span className="cu-title">Career & learning</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1195} alt="cu-icon" /><span className="cu-title">Other workplace poliies</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1199} alt="cu-icon" /><span className="cu-title">DE&I Tool kit</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1203} alt="cu-icon" /><span className="cu-title">Retirement resources</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1207} alt="cu-icon" /><span className="cu-title">Pay & performance</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1211} alt="cu-icon" /><span className="cu-title">Recognition & community</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1215} alt="cu-icon" /><span className="cu-title">Workday</span>
        </div>
        </div><div className="card-useful">
        <div className="cu-contain">
        <img className="cu-icon" src={img_1219} alt="cu-icon" /><span className="cu-title">Business cards and stationary</span>
        </div>
        </div>
        </div>
        </div><div className="footer">
        <div className="footer-contain">
        <span className="contact-us">Contact Us</span><div className="copy-rigth">
        <img className="img-copyright" src={img_1225} alt="img-copyright" /><span className="footer-text">2024 Pichincha</span>
        </div>
        </div>
        </div>
        </div>
  )
  }
  
  export default Home;
  